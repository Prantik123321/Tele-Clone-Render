## Packages
date-fns | Formatting timestamps in chat
framer-motion | Smooth transitions for mobile navigation and message bubbles
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
}
